console.log("Azitis încarcat...");0

